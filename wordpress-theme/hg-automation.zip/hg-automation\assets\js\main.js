/**
 * HG Automation Theme JavaScript
 * Handles navigation, animations, and contact form
 */

(function() {
    'use strict';

    // DOM Elements
    const header = document.getElementById('site-header');
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');
    const navLinks = document.querySelectorAll('.nav-link, .mobile-nav-link');
    const sections = document.querySelectorAll('section[id]');
    const contactForm = document.getElementById('contact-form');

    /**
     * Header scroll effect
     */
    function handleScroll() {
        if (window.scrollY > 20) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }

        // Update active nav link based on scroll position
        updateActiveSection();
    }

    /**
     * Update active navigation link based on scroll position
     */
    function updateActiveSection() {
        const scrollPosition = window.scrollY + 100;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');

            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                // Update desktop nav
                document.querySelectorAll('.nav-link').forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('data-section') === sectionId) {
                        link.classList.add('active');
                    }
                });

                // Update mobile nav
                document.querySelectorAll('.mobile-nav-link').forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('data-section') === sectionId) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }

    /**
     * Smooth scroll to section
     */
    function scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            const offsetTop = section.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    }

    /**
     * Mobile menu toggle
     */
    function toggleMobileMenu() {
        mobileMenuToggle.classList.toggle('active');
        mobileMenu.classList.toggle('active');
        mobileMenuToggle.setAttribute('aria-expanded',
            mobileMenuToggle.classList.contains('active').toString()
        );

        // Prevent body scroll when menu is open
        if (mobileMenu.classList.contains('active')) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
    }

    /**
     * Close mobile menu
     */
    function closeMobileMenu() {
        mobileMenuToggle.classList.remove('active');
        mobileMenu.classList.remove('active');
        mobileMenuToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
    }

    /**
     * Handle navigation link click
     */
    function handleNavClick(e) {
        e.preventDefault();
        const sectionId = this.getAttribute('data-section') || this.getAttribute('href').replace('#', '');
        scrollToSection(sectionId);
        closeMobileMenu();
    }

    /**
     * Handle contact form submission
     */
    function handleContactForm(e) {
        e.preventDefault();

        const formMessage = document.getElementById('form-message');
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const btnText = submitBtn.querySelector('.btn-text');
        const btnLoading = submitBtn.querySelector('.btn-loading');
        const btnIcon = submitBtn.querySelector('.btn-icon');

        // Clear previous errors
        document.querySelectorAll('.field-error').forEach(el => el.textContent = '');
        document.querySelectorAll('.input-field').forEach(el => el.classList.remove('error'));
        formMessage.innerHTML = '';

        // Get form data
        const formData = new FormData(contactForm);
        formData.append('action', 'hg_contact_form');
        formData.append('nonce', typeof hgAutomation !== 'undefined' ? hgAutomation.nonce : '');

        // Client-side validation
        let hasErrors = false;
        const name = formData.get('name');
        const email = formData.get('email');
        const subject = formData.get('subject');
        const message = formData.get('message');

        if (!name || !name.trim()) {
            showFieldError('name', 'Name is required');
            hasErrors = true;
        }

        if (!email || !email.trim()) {
            showFieldError('email', 'Email is required');
            hasErrors = true;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            showFieldError('email', 'Please enter a valid email');
            hasErrors = true;
        }

        if (!subject || !subject.trim()) {
            showFieldError('subject', 'Subject is required');
            hasErrors = true;
        }

        if (!message || !message.trim()) {
            showFieldError('message', 'Message is required');
            hasErrors = true;
        } else if (message.length < 20) {
            showFieldError('message', 'Message must be at least 20 characters');
            hasErrors = true;
        }

        if (hasErrors) return;

        // Show loading state
        btnText.style.display = 'none';
        btnIcon.style.display = 'none';
        btnLoading.style.display = 'inline-flex';
        submitBtn.disabled = true;

        // Send AJAX request
        const ajaxUrl = typeof hgAutomation !== 'undefined' ? hgAutomation.ajaxUrl : '/wp-admin/admin-ajax.php';

        fetch(ajaxUrl, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                formMessage.innerHTML = `
                    <div class="form-message success">
                        <svg viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                        </svg>
                        <p>${data.data.message}</p>
                    </div>
                `;
                contactForm.reset();
            } else {
                if (data.data && data.data.errors) {
                    Object.keys(data.data.errors).forEach(field => {
                        showFieldError(field, data.data.errors[field]);
                    });
                } else {
                    formMessage.innerHTML = `
                        <div class="form-message error">
                            <svg viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                            </svg>
                            <p>${data.data.message || 'Something went wrong. Please try again.'}</p>
                        </div>
                    `;
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
            formMessage.innerHTML = `
                <div class="form-message error">
                    <svg viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                    </svg>
                    <p>Network error. Please check your connection and try again.</p>
                </div>
            `;
        })
        .finally(() => {
            // Reset button state
            btnText.style.display = '';
            btnIcon.style.display = '';
            btnLoading.style.display = 'none';
            submitBtn.disabled = false;
        });
    }

    /**
     * Show field error
     */
    function showFieldError(field, message) {
        const errorEl = document.getElementById(`error-${field}`);
        const inputEl = document.getElementById(`contact-${field}`);

        if (errorEl) {
            errorEl.textContent = message;
        }

        if (inputEl) {
            inputEl.classList.add('error');
        }
    }

    /**
     * Intersection Observer for animations
     */
    function setupAnimations() {
        const animatedElements = document.querySelectorAll('.service-card, .about-visual, .about-content, .contact-info, .contact-form-wrapper');

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-fadeInUp');
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1
        });

        animatedElements.forEach(el => {
            el.style.opacity = '0';
            observer.observe(el);
        });
    }

    /**
     * Initialize
     */
    function init() {
        // Scroll handler
        window.addEventListener('scroll', handleScroll);
        handleScroll(); // Initial check

        // Mobile menu toggle
        if (mobileMenuToggle) {
            mobileMenuToggle.addEventListener('click', toggleMobileMenu);
        }

        // Close mobile menu when clicking overlay
        if (mobileMenu) {
            const overlay = mobileMenu.querySelector('.mobile-menu-overlay');
            if (overlay) {
                overlay.addEventListener('click', closeMobileMenu);
            }
        }

        // Navigation links
        navLinks.forEach(link => {
            link.addEventListener('click', handleNavClick);
        });

        // Scroll indicator and other anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href && href !== '#') {
                    e.preventDefault();
                    const sectionId = href.replace('#', '');
                    scrollToSection(sectionId);
                    closeMobileMenu();
                }
            });
        });

        // Contact form
        if (contactForm) {
            contactForm.addEventListener('submit', handleContactForm);
        }

        // Setup animations
        setupAnimations();

        // Clear input errors on focus
        document.querySelectorAll('.input-field').forEach(input => {
            input.addEventListener('focus', function() {
                this.classList.remove('error');
                const errorEl = document.getElementById(`error-${this.name}`);
                if (errorEl) {
                    errorEl.textContent = '';
                }
            });
        });
    }

    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
