<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="HG Automation - Industrial automation experts. PLC programming, SCADA systems, control panels, and Industry 4.0 solutions.">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Header -->
<header class="site-header" id="site-header">
    <div class="container header-container">
        <!-- Logo -->
        <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
            <?php if (has_custom_logo()): ?>
                <?php
                $custom_logo_id = get_theme_mod('custom_logo');
                $logo_url = wp_get_attachment_image_url($custom_logo_id, 'full');
                ?>
                <img src="<?php echo esc_url($logo_url); ?>" alt="<?php bloginfo('name'); ?>" class="logo-image">
            <?php else: ?>
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/Logo.png" alt="<?php bloginfo('name'); ?>" class="logo-image">
            <?php endif; ?>
            <div class="logo-text">
                <h1>HG <span>AUTOMATION</span></h1>
                <p>Precision Control. Optimized Performance</p>
            </div>
        </a>

        <!-- Desktop Navigation -->
        <nav class="main-nav">
            <a href="#home" class="nav-link active" data-section="home">Home</a>
            <a href="#services" class="nav-link" data-section="services">Services</a>
            <a href="#about" class="nav-link" data-section="about">About</a>
            <a href="#contact" class="nav-link" data-section="contact">Contact</a>
        </nav>

        <!-- Mobile Menu Toggle -->
        <button class="mobile-menu-toggle" aria-label="Toggle menu" aria-expanded="false">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
    </div>
</header>

<!-- Mobile Menu -->
<div class="mobile-menu" id="mobile-menu">
    <div class="mobile-menu-overlay"></div>
    <div class="mobile-menu-content">
        <nav class="mobile-nav">
            <a href="#home" class="mobile-nav-link active" data-section="home">
                <span class="icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                    </svg>
                </span>
                <span class="text">
                    <span>Home</span>
                    <small>Back to top</small>
                </span>
            </a>
            <a href="#services" class="mobile-nav-link" data-section="services">
                <span class="icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                    </svg>
                </span>
                <span class="text">
                    <span>Services</span>
                    <small>What we offer</small>
                </span>
            </a>
            <a href="#about" class="mobile-nav-link" data-section="about">
                <span class="icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </span>
                <span class="text">
                    <span>About</span>
                    <small>Our story</small>
                </span>
            </a>
            <a href="#contact" class="mobile-nav-link" data-section="contact">
                <span class="icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                    </svg>
                </span>
                <span class="text">
                    <span>Contact</span>
                    <small>Get in touch</small>
                </span>
            </a>
        </nav>
    </div>
</div>

<main>
